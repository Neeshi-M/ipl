
#include "scanner.hh"
#include "parser.tab.hh"
#include <fstream>
#include <unordered_map>
using namespace std;
extern int our_type;
SymbTab gst, gstfun, gststruct; 
string filename;
extern std::string parser_output;
extern std::map<string,abstract_astnode*> ast;
std::map<std::string, datatype> predefined {
            {"printf", createtype(VOID_TYPE)},
            {"scanf", createtype(VOID_TYPE)},
            {"mod", createtype(INT_TYPE)}
        };
extern map<std::string, SymbTabEntry> all_variables;
extern std::unordered_map<std::string, map<std::string, SymbTabEntry>> all_structs;


int main(int argc, char **argv)
{
	fstream in_file, out_file;
	using namespace std;
	

	in_file.open(argv[1], ios::in);
	cout << "	.file	\"" << argv[1] << "\"\n";
	cout << "	.text\n";


	IPL::Scanner scanner(in_file);


	IPL::Parser parser(scanner);


#ifdef YYDEBUG

	parser.set_debug_level(1);
#endif

parser.parse();


// create gstfun with function entries only

for (const auto &entry : gst.Entries)
{	
	if (entry.second.varfun == "fun"){
		
		// if(entry.first=="main"){
		// 	cout << "	.section .rodata\n";

		// }
		// else if(entry.first!="main"){
		// cout << "   .globl " << entry.first << endl;
		// cout << "   .type " << entry.first << ", @function\n"; 
		// }

	gstfun.Entries.insert({entry.first, entry.second});
	}

}
int is_func = 0;
for (const auto &entry : gst.Entries)
{	
	if (entry.second.varfun == "fun"){
		
		// if(entry.first=="main"){
		// 	cout << "	.section .rodata\n";

		// }
		if(entry.first!="main"){
		is_func = 1;
		cout << "   .globl " << entry.first << endl;
		cout << "   .type " << entry.first << ", @function\n"; 
		}

	gstfun.Entries.insert({entry.first, entry.second});
	}

}
// if(is_func == 0){
// 	cout << "	.section .rodata\n";
// }

// create gststruct with struct entries only

for (const auto &entry : gst.Entries)
{
	if (entry.second.varfun == "struct")
	gststruct.Entries.insert({entry.first, entry.second});
}

// start the JSON printing

// cout << "{\"globalST\": " << endl;

//gst.printgst();
// cout << "," << endl;

// cout << "  \"structs\": [" << endl;

for (auto it = gststruct.Entries.begin(); it != gststruct.Entries.end(); ++it)

{   
	all_structs[it->first] = it->second.symbtab->Entries;
	//cout << "\"name\": " << "\"" << it->first << "\"," << endl;

	for (auto a = all_structs[it->first].begin(); a != all_structs[it->first].end(); ++a){
		//cout << a->first << " " << a->second.offset << endl;
	}
	// cout << "{" << endl;
	// cout << "\"name\": " << "\"" << it->first << "\"," << endl;
	// cout << "\"localST\": " << endl;
	// it->second.symbtab->print();
	// cout << "}" << endl;
	// if (next(it,1) != gststruct.Entries.end()) 
	// cout << "," << endl;
}

// cout << "]," << endl;
// cout << "  \"functions\": [" << endl;

for (auto it = gstfun.Entries.begin(); it != gstfun.Entries.end(); ++it)
{
	if(it->first == "main"){
        cout << parser_output << endl;	
		cout << "main:\n";
		cout << "   endbr32\n";
		cout << "	pushl %ebp\n";
		cout << "	movl %esp, %ebp\n";
		all_variables = it->second.symbtab->Entries;
		int max_offset;
		max_offset = 0;
	
		for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
			max_offset = max(max_offset , abs(a->second.offset));
			//cout << a->first  <<"," << max_offset << endl;
    		}
		cout << "   subl $"<<max_offset << ", %esp\n";
		//uncomment this when u write a code for abstract_astnode print
		// for(auto b = ast.begin(); b!= ast.end(); ++b){
		// 	cout << b->first;
		// }
		ast["main"]->print(0);
		cout << "   movl $0, %eax\n";
		// cout << "   leave\n";
		// cout << "   ret\n";
	// 	for (auto a = it->second.symbtab->Entries.begin(); a != it->second.symbtab->Entries.end(); ++a) {
	// 		cout << a->first<< "  "<< a->second.varfun << a->second.symbtab<<endl;
			
    //     // std::cout << "Key: " << a->first << std::endl;
    //     // std::cout << "Value: " << a->second << std::endl;
    // }
		// vari = it->second.symbtab->variables;
		// ast["main"]->print(1); // 1 to denote stack management
	}


	if(it->first != "main"){
		cout << it->first << ":" << endl;
		cout << "   endbr32\n";
		cout << "	pushl %ebp\n";
		cout << "	movl %esp, %ebp\n";
		all_variables = it->second.symbtab->Entries;
		//uncomment this when u write a code for abstract_astnode print
		// for(auto b = ast.begin(); b!= ast.end(); ++b){
		// 	cout << b->first;
		// }
		our_type = 10;
		ast[it->first]->print(0);
		if(it->second.type.type == 0){
			cout << "   leave\n";
		}
		else{
			cout << "   popl %ebp\n";
		}
		
		cout << "   ret\n";
		cout << "   .size " << it->first << ", .-" << it->first <<endl;
		
	// 	for (auto a = it->second.symbtab->Entries.begin(); a != it->second.symbtab->Entries.end(); ++a) {
	// 		cout << a->first<< "  "<< a->second.varfun << a->second.symbtab<<endl;
			
    //     // std::cout << "Key: " << a->first << std::endl;
    //     // std::cout << "Value: " << a->second << std::endl;
    // }
		// vari = it->second.symbtab->variables;
		// ast["main"]->print(1); // 1 to denote stack management
	}


	// cout << "{" << endl;
	// cout << "\"name\": " << "\"" << it->first << "\"," << endl;
	// cout << "\"localST\": " << endl;
	// it->second.symbtab->print();
	// cout << "," << endl;
	// cout << "\"ast\": " << endl;
	// ast[it->first]->print(0);
	// cout << "}" << endl;
	// if (next(it,1) != gstfun.Entries.end()) cout << "," << endl;

	
}
	cout << "   .section .rodata\n";
	// cout << "]" << endl;
	// cout << "}" << endl;

	fclose(stdout);
}
// void printAst(const char *astname, const char *fmt...) // fmt is a format string that tells about the type of the arguments.
// {   
// 	typedef vector<abstract_astnode *>* pv;
// 	va_list args;
// 	va_start(args, fmt);
// 	if ((astname != NULL) && (astname[0] != '\0'))
// 	{
// 		cout << "{ ";
// 		cout << "\"" << astname << "\"" << ": ";
// 	}
// 	cout << "{" << endl;
// 	while (*fmt != '\0')
// 	{
// 		if (*fmt == 'a')
// 		{
// 			char * field = va_arg(args, char *);
// 			abstract_astnode *a = va_arg(args, abstract_astnode *);
// 			cout << "\"" << field << "\": " << endl;
			
// 			a->print(0);
// 		}
// 		else if (*fmt == 's')
// 		{
// 			char * field = va_arg(args, char *);
// 			char *str = va_arg(args, char *);
// 			cout << "\"" << field << "\": ";

// 			cout << str << endl;
// 		}
// 		else if (*fmt == 'i')
// 		{
// 			char * field = va_arg(args, char *);
// 			int i = va_arg(args, int);
// 			cout << "\"" << field << "\": ";

// 			cout << i;
// 		}
// 		else if (*fmt == 'f')
// 		{
// 			char * field = va_arg(args, char *);
// 			double f = va_arg(args, double);
// 			cout << "\"" << field << "\": ";
// 			cout << f;
// 		}
// 		else if (*fmt == 'l')
// 		{
// 			char * field = va_arg(args, char *);
// 			pv f =  va_arg(args, pv);
// 			cout << "\"" << field << "\": ";
// 			cout << "[" << endl;
// 			for (int i = 0; i < (int)f->size(); ++i)
// 			{
// 				(*f)[i]->print(0);
// 				if (i < (int)f->size() - 1)
// 					cout << "," << endl;
// 				else
// 					cout << endl;
// 			}
// 			cout << endl;
// 			cout << "]" << endl;
// 		}
// 		++fmt;
// 		if (*fmt != '\0')
// 			cout << "," << endl;
// 	}
// 	cout << "}" << endl;
// 	if ((astname != NULL) && (astname[0] != '\0'))
// 		cout << "}" << endl;
// 	va_end(args);
// }

