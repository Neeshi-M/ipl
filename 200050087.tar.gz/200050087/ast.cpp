









// #include "ast.hh"
// #include <cstdarg>
// #include <bits/stdc++.h>
// #include "symbtab.hh"
// //////////////////////////////

// // statement_astnode::statement_astnode()
// // {
// // }

// /////////////////////////////
// // eax ecx edx esi edi ebx
// //my order of 
// map<std::string, SymbTabEntry> all_variables;
// int total_jumps = 0;

// int our_type;
// void printmovlorand(int our_type , int zero_or_one){
//     if(our_type == 1 || our_type == 3){
//         cout << "   movl $" << std::to_string(zero_or_one) << ", %eax\n";
//     }
// 	else if(our_type == 2 || our_type == 4){
//         cout << "   movl $" << std::to_string(zero_or_one) << ", %ecx\n";
//     }
// }

// void comparegencode(std::string jump_type, int jumps){
// 	std::string codeString;
// 	codeString += "   cmpl $0,";
// 	codeString = codeString + " %eax\n";
// 	codeString += "   " + jump_type +" .L" + std::to_string(jumps) + "\n";

// 	std::cout << codeString;
// }

// void onecompare(std::string jump_type, int jumps){
// 	std::string codeString;
// 	codeString += "   cmpl $1,";
// 	codeString = codeString + " %eax\n";
// 	codeString += "   " + jump_type +" .L" + std::to_string(jumps) + "\n";

// 	std::cout << codeString;
// }


// void jump_statement(int jumps){
// 	std::string codeString;
// 	codeString =  ".L" + std::to_string(jumps) + ":\n";
// 	std::cout << codeString;
// }


// empty_astnode::empty_astnode() : statement_astnode()
// {
// 	astnode_type = EmptyNode;
// }

// void empty_astnode::print(int ntabs)
// {
// 	//#cout << "\"empty\"" << endl;
// }

// //////////////////////////

// seq_astnode::seq_astnode() : statement_astnode()
// {
	
// 	astnode_type = SeqNode;
// }

// void seq_astnode::pushback(statement_astnode *child)
// {
// 	children_nodes.push_back(child);
// }

// void seq_astnode::print(int ntabs)
// {
// 	printblanks(ntabs);
// 	int max_offset;
// 	max_offset = 0;
	
// 		for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
// 			max_offset = max(max_offset , abs(a->second.offset));
//     		}
// 	cout << "   subl $"<<max_offset << ", %esp\n";
// 	printAst("", "l", "seq", &children_nodes);
// }

// ///////////////////////////////////

// assignS_astnode::assignS_astnode(exp_astnode *l, exp_astnode *r, string tc) : statement_astnode()
// {
// 	typecast = tc;
// 	left = l;
// 	right = r;
// 	id = "Ass";
// 	astnode_type = AssNode;
// }

// void assignS_astnode::print(int ntabs)
// {
// 	//#cout << " reached assignS_astnode" <<endl;
// 	our_type = 3;
// 	right->print(0);
// 	our_type = 1;
// 	left->print(0);
// 	//printAst("assignS", "aa", "left", left, "right", right);
// }

// ///////////////////////////////////

// return_astnode::return_astnode(exp_astnode *c) : statement_astnode()
// {
// 	child = c;
// 	id = "Return";
// 	astnode_type = ReturnNode;
// }
// void return_astnode::print(int ntabs)
// {
// 	//#cout << "reached return_astnode"<<endl;
// 	printAst("", "a", "return", child);
// }

// ////////////////////////////////////

// if_astnode::if_astnode(exp_astnode *l, statement_astnode *m, statement_astnode *r) : statement_astnode()
// {
// 	left = l;
// 	middle = m;
// 	right = r;
// 	id = "If";
// 	astnode_type = IfNode;
// }

// void if_astnode::print(int ntabs)
// {
// 	//#cout << "reached if_astnode "<< endl;
// 	int v = total_jumps;
// 	if(left){
// 		total_jumps = total_jumps +2;

// 		int here_type;
// 		here_type = our_type;
// 		our_type = 3;
//         left->print(0);
// 		our_type = here_type;
// 		onecompare("jne", v);
		
		
// 	}
// 	else{}
// 	if(middle){
// 		int here_type_1;
// 		here_type_1 = our_type;
// 		our_type = 3;
//         middle->print(0);
// 		our_type = here_type_1;
// 		cout << "   jmp	.L" << v+1 << "\n";

// 	}else{}
// 	if(right){
// 		jump_statement(v);
// 		int here_type_3;
// 		here_type_3 = our_type;
// 		our_type = 3;
//         right->print(0);
// 		our_type = here_type_3;
// 		jump_statement(v+1);
// 	}
// 	else{
// 		jump_statement(v);
// 		int here_type_3;
// 		here_type_3 = our_type;
// 		our_type = 2;
//         right->print(0);
// 		our_type = here_type_3;
// 		jump_statement(v+1);
// 	}
	
// 	// printAst("if", "aaa",
// 	// 		 "cond", left,
// 	// 		 "then", middle,
// 	// 		 "else", right);
// }
// ////////////////////////////////////

// while_astnode::while_astnode(exp_astnode *l, statement_astnode *r) : statement_astnode()
// {
// 	left = l;
// 	right = r;
// 	id = "While";
// 	astnode_type = WhileNode;
// }

// void while_astnode::print(int ntabs)
// {	
// 	int v = total_jumps;
// 	if(right){
// 		total_jumps = total_jumps + 2;
//         cout << "   jmp	.L" << v << "\n";
// 		jump_statement(v+1);
// 		int here_type;
// 		here_type = our_type;
// 		our_type = 3;
// 		right->print(0);
// 		our_type = here_type;


// 	}
// 	if(left){
// 		jump_statement(v);
// 		int here_type_1;
// 		here_type_1 = our_type;
// 		our_type = 3;
// 		left->print(0);
// 		our_type = here_type_1;
// 		onecompare("je",v+1);
		


// 	}
	
// 	//#cout << "reached while_astnode"<<endl;
// 	// printAst("while", "aa",
// 	// 		 "cond", left,
// 	// 		 "stmt", right);
// }
// /////////////////////////////////

// for_astnode::for_astnode(exp_astnode *l, exp_astnode *m1, exp_astnode *m2, statement_astnode *r) : statement_astnode()
// {
// 	left = l;
// 	middle1 = m1;
// 	middle2 = m2;
// 	right = r;
// 	id = "For";
// 	astnode_type = ForNode;
// }

// void for_astnode::print(int ntabs)
// {


// 	int v = total_jumps;
// 	if(left){
		
// 		total_jumps = total_jumps + 2;
// 		int here_type;
// 		here_type = our_type;
// 		our_type = 3;
//         left->print(0);
// 		our_type = here_type;
//         cout << "   jmp .L" << v << "\n";
// 		jump_statement(v+1);
// 	}
// 	else{

// 	}
// 	if(right){
// 		int here_type_3;
// 		here_type_3 = our_type;
// 		our_type = 3;
//         right->print(0);
// 		our_type = here_type_3;
// 	}
// 	else{

// 	}
// 	if(middle2){
// 		int here_type_2;
// 		here_type_2 = our_type;
// 		our_type = 3;
//         middle2->print(0);
// 		our_type = here_type_2;
// 		jump_statement(v);
// 	}
// 	else{

// 	}
// 	if(middle1){
// 		int here_type_1;
// 		here_type_1 = our_type;
// 		our_type = 3;
//         middle1->print(0);
// 		our_type = here_type_1;
// 		onecompare("je", v+1);
		
// 	}
// 	else{

// 	}
	


	
//     // cout << "\"body\": " << endl;
// 	//#cout << "reached for_astnode"<<endl;
// // 	printAst("for", "aaaa",
// // 			 "init", left,
// // 			 "guard", middle1,
// // 			 "step", middle2,
// // 			 "body", right);
// // 
// }

// //////////////////////////////////

// // exp_astnode::exp_astnode() : abstract_astnode()
// // {
// // }

// //////////////////////////////////
// string exp_astnode::idname()
// {
// 	return id;
// };
// op_binary_astnode::op_binary_astnode(string val, exp_astnode *l, exp_astnode *r) : exp_astnode()
// {
// 	id = val;
// 	left = l;
// 	right = r;
// 	astnode_type = OpBinaryNode;
// }

// void op_binary_astnode::print(int ntabs)
// {
// 	//#cout << "reached op_binary_astnode"<<endl;
// 	if((id == "PLUS_INT" || id == "MINUS_INT" || id == "MULT_INT" ) && (our_type == 3 || our_type == 4 || our_type == 5)){
// 		int here_type;
// 		std::string str_out;
// 		str_out = "";
// 		if (id == "PLUS_INT"){
// 		str_out = str_out + "   addl ";
// 		}
// 		else if( id == "MINUS_INT" ){
// 		str_out = str_out + "   subl ";
// 		}
// 		else if( id == "MULT_INT"){
// 		str_out = str_out + "   imull ";
// 		}
// 		here_type = our_type;
// 		left->print(0);
// 		our_type = our_type + 1;
// 		right->print(0);
// 		our_type = here_type;
		

// 		if(here_type==3){
// 			str_out = str_out + "%ecx, ";
// 			str_out = str_out + "%eax";
// 		}
// 		if(here_type == 5){
// 			str_out = str_out + "%esi, ";
// 			str_out = str_out + "%edx";
// 		}
// 		if(here_type == 4){
// 			str_out = str_out + "%edx, ";
// 			str_out = str_out + "%ecx";
// 		}
		
// 		cout << str_out << endl;


// 	}


// 	if((id == "DIV_INT") && (our_type == 3 || our_type == 4 || our_type == 5)){
// 		int here_type;
// 		std::string str_out;
// 		str_out = "";
// 		here_type = our_type;
// 		left->print(0);
// 		our_type = our_type + 1;
// 		right->print(0);
// 		our_type = here_type;
// 		if(here_type == 3){
// 			str_out+="   movl %eax, %edx\n";
//             str_out+="   movl $1234, %eax\n";
//             str_out+="   movl $0, %esi\n";
//             str_out+="   movl %edx, %eax\n";
//             str_out+="   cltd\n";
//             str_out+="   idivl %ecx\n";
// 		}
		
// 		if(here_type == 4){
			
// 			str_out += "   movl %eax, %esi\n   movl %ecx, %eax\n   movl %edx, %edi\n";
//             str_out = str_out + "   cltd\n";
//             str_out = str_out + "   idivl %edi\n";
// 			str_out += "   movl %eax, %ecx\n   movl %esi, %eax\n";
            
// 		}

// 		if(here_type == 5){
			
// 			str_out += "   movl %eax, %edi\n   movl %edx, %eax\n";
// 			str_out = str_out + "   cltd\n";
// 			str_out = str_out + "   idivl %esi\n";
// 			str_out += "   movl %eax, %edx\n   movl %edi, %eax\n";
			
// 		}


// 		cout << str_out;
// 	}






// 	// if((id == "DIV_INT") && (our_type == 3 || our_type == 4 || our_type == 5)){
// 	// 	int here_type;
// 	// 	std::string str_out;
// 	// 	str_out = "";
// 	// 	here_type = our_type;
// 	// 	left->print(0);
// 	// 	our_type = our_type + 1;
// 	// 	right->print(0);
// 	// 	our_type = here_type;

// 	// 	if(here_type == 3){
// 	// 		// code+="movl %eax, %edi\n";
//     //         // code+="movl $1234, %eax\n";
//     //         // code+="movl $0, %edx\n";
//     //         // code+="movl %edi, %eax\n";
//     //         // code+="cltd\n";
//     //         // code+="idivl %ecx\n";
// 	// 		// str_out+="   movl %eax, %edx\n";
//     //         // str_out+="   movl $1234, %eax\n";
//     //         // str_out+="   movl $0, %esi\n";
//     //         // str_out+="   movl %edx, %eax\n";
//     //         // str_out+="   cltd\n";
//     //         // str_out+="   idivl %ecx\n";
// 	// 	}
		
// 	// 	if(here_type == 4){
// 	// 		// code+="movl %eax, %ebx\n";
//     //         // code+="movl $1234, %eax\n";
// 	// 		// code+="movl %edx, %edi\n";

//     //         // code+="movl $0, %edx\n";
//     //         // code+="movl %ecx, %eax\n";
//     //         // code+="cltd\n";
//     //         // code+="idivl %edi\n";
//     //         // code+="movl %eax, %ecx\n";
//     //         // code+="movl %ebx, %eax\n";
			
// 	// 		// str_out += "   movl %eax, %esi\n   movl %ecx, %eax\n   movl %edx, %edi\n";
//     //         // str_out = str_out + "   cltd\n";
//     //         // str_out = str_out + "   idivl %edi\n";
// 	// 		// str_out += "   movl %eax, %ecx\n   movl %esi, %eax\n   movl %edi, %edx\n";

           
// 	// 	}

// 	// 	if(here_type == 5){
// 	// 		// code+="movl %eax, %ebx\n";
//     //         // code+="movl %edx, %eax\n";
//     //         // code+="movl $1234, %eax\n";
//     //         // code+="movl $0, %edx\n";
//     //         // code+="cltd\n";
//     //         // code+="idivl %esi\n";
//     //         // code+="movl %eax, %edx\n";
//     //         // code+="movl %ebx, %eax\n";
// 	// 		// str_out += "   movl %eax, %edi\n   movl %edx, %eax\n   movl %esi, %ebx\n";
// 	// 		// str_out = str_out + "   cltd\n";
// 	// 		// str_out = str_out + "   idivl %esi\n";
// 	// 		// str_out += "   movl %eax, %edx\n   movl %edi, %eax\n   movl %ebx, %esi\n";
			
// 	// 	}
		
// 	// 	// if(here_type == 3){
// 	// 	// 	// code+="movl %eax, %edx\n";
//     //     //     // code+="movl $1234, %eax\n";
//     //     //     // code+="movl $0, %esi\n";
//     //     //     // code+="movl %edx, %eax\n";
//     //     //     // code+="cltd\n";
//     //     //     // code+="idivl %ecx\n";
// 	// 	// 	// str_out+="   movl %eax, %edx\n";
//     //     //     // str_out+="   movl $1234, %eax\n";
//     //     //     // str_out+="   movl $0, %esi\n";
//     //     //     // str_out+="   movl %edx, %eax\n";
// 	// 	// 	//cout << "in case 3\n";
// 	// 	// 	//str_out+="   movl %edx, %esi\n";
//     //     //     // str_out+="   cltd\n";
//     //     //     // str_out+="   idivl %ecx\n";
// 	// 	// 	//str_out+="   movl %esi, %edx\n";
// 	// 	// }
		
// 	// 	// if(here_type == 4){
// 	// 	// 	// code+="movl %eax, %ebx\n";
//     //     //     // code+="movl $1234, %eax\n";
//     //     //     // code+="movl $0, %esi\n";
//     //     //     // code+="movl %ecx, %eax\n";
//     //     //     // code+="cltd\n";
//     //     //     // code+="idivl %edx\n";
//     //     //     // code+="movl %eax, %ecx\n";
//     //     //     // code+="movl %ebx, %eax\n";
// 	// 	//     //cout << "in case 4\n";

// 	// 	// 	// str_out += "   movl %eax, %esi\n   movl %ecx, %eax\n   movl %edx, %edi\n";
//     //     //     // str_out = str_out + "   cltd\n";
//     //     //     // str_out = str_out + "   idivl %edi\n";
// 	// 	// 	// str_out += "   movl %eax, %ecx\n   movl %esi, %eax\n   movl %edi, %edx\n";
           
// 	// 	// }

// 	// 	// if(here_type == 5){
// 	// 	// 	// code+="movl %eax, %ebx\n";
//     //     //     // code+="movl %esi, %edi\n";
//     //     //     // code+="movl $1234, %eax\n";
//     //     //     // code+="movl $0, %esi\n";
//     //     //     // code+="movl %edx, %eax\n";
//     //     //     // code+="cltd\n";
//     //     //     // code+="idivl %edi\n";
//     //     //     // code+="movl %eax, %edx\n";
//     //     //     // code+="movl %ebx, %eax\n";
// 	// 	// 	//cout << "in case 5\n";

// 	// 	// 	// str_out += "   movl %eax, %edi\n   movl %edx, %eax\n";
// 	// 	// 	// str_out = str_out + "   cltd\n";
// 	// 	// 	// str_out = str_out + "   idivl %esi\n";
// 	// 	// 	// str_out += "   movl %eax, %edx\n   movl %edi, %eax\n";
			
// 	// 	// }


// 	// 	cout << code;
// 	// }

// 	if((id == "AND_OP") && (our_type == 1 || our_type == 2 || our_type == 3 || our_type == 4)){
//         int here_type;
// 		here_type = our_type;
// 		our_type = 3;
//         left->print(0);
// 		our_type = here_type;
//         comparegencode("je", total_jumps);
//         here_type = our_type;
// 		our_type = 3;
//         right->print(0);
// 		our_type = here_type;
// 	    comparegencode("je", total_jumps);
//         total_jumps++;
// 	    printmovlorand(our_type, 1);
// 	    cout << "   jmp	.L" << total_jumps << "\n";
//         jump_statement(total_jumps-1);
//         printmovlorand(our_type, 0);
//         jump_statement(total_jumps);
//         total_jumps++;
//         total_jumps++;
//     }

// 	  if((id == "GT_OP_INT" || id == "LT_OP_INT" || id == "GE_OP_INT" || id == "LE_OP_INT" || id == "EQ_OP_INT" || id == "NE_OP_INT") && (our_type == 3 || our_type == 4 || our_type == 5)){
//         int here_type;
// 		std::string str_out;
// 		str_out = "";
// 		here_type = our_type;
// 		left->print(0);
// 		our_type = our_type + 1;
// 		right->print(0);
// 		our_type = here_type;
// 		str_out = str_out + "   cmpl %ecx, ";
//         if(here_type == 3){
// 			str_out = str_out + "%eax\n";
// 		}
//         else if(here_type == 4){
// 			str_out = str_out + "%ecx\n";
// 		}
//         else if(here_type == 5){
// 			str_out = str_out + "%edx\n";
// 		}
//         else{

//         }
// 		if(id == "GT_OP_INT"){
// 			str_out = str_out + "   setg %al\n";
// 		}
// 		else if(id == "LT_OP_INT"){
// 			str_out = str_out + "   setl %al\n";
// 		}
// 		else if(id == "GE_OP_INT"){
// 			str_out = str_out + "   setge %al\n";
// 		}
// 		else if(id == "LE_OP_INT"){
// 			str_out = str_out + "   setle %al\n";
// 		}
// 		else if(id == "EQ_OP_INT"){
// 			str_out = str_out + "   sete %al\n";
// 		}
// 		else if(id == "NE_OP_INT"){
// 			str_out = str_out + "   setne %al\n";
// 		}
//         else{

//         }
// 		str_out = str_out + "   movzbl %al, ";
//         if(here_type == 3){
// 			str_out = str_out + "%eax\n";
// 		}
//         else if(here_type == 4){
// 			str_out = str_out + "%ecx\n";
// 		}
//         else if(here_type == 5){
// 			str_out = str_out + "%edx\n";
// 		}
//         else{

//         }
//         cout << str_out;


        

    






//     }

	

//     // if(id == "OR_OP" || id == "AND_OP"){
// 	// 	int here_type;
// 	// 	std::string str_out;
// 	// 	str_out = "";
// 	// 	here_type = our_type;
// 	// 	our_type = 3;
// 	// 	left->print(0);
// 	// 	our_type = here_type;
// 	// 	cout << "   cmpl	$0, %eax\n";
// 	// 	if(id == "OR_OP"){
// 	// 		cout << "   jne ";
// 	// 	}
// 	// 	else{
// 	// 		cout << "   je  ";
// 	// 	}
      
// 	// 	cout << ".L" << std::to_string(total_jumps) << endl;
// 	// 	if(id == "OR_OP"){
// 	// 		total_jumps = total_jumps + 1;
// 	// 	}
//     //     else{}
// 	// 	here_type = our_type;
// 	// 	our_type = 3;
// 	// 	right->print(0);
// 	// 	our_type = here_type;
		
// 	// 	cout << "   cmpl	$0, %eax\n";
// 	// 	cout << "   je  ";
// 	// 	cout << ".L" << std::to_string(total_jumps) << endl;
// 	// 	total_jumps = total_jumps + 1;

// 	// 	if(id == "OR_OP"){
// 	// 		cout << ".L" << std::to_string(total_jumps-2) << ":\n";

// 	// 	}
//     //     else{}
// 	// 	str_out = "   movl	$1, ";

// 	// 	if(our_type == 3 || our_type == 1){
// 	// 		str_out = str_out + "%eax\n";
// 	// 	}
// 	// 	else if(our_type == 4 || our_type == 2){
// 	// 		str_out = str_out + "%ecx\n";
// 	// 	}
//     //     else{}
// 	// 	str_out = str_out + "   jmp .L" + std::to_string(total_jumps) + "\n";
		
// 	// 	if(id == "OR_OP"){
			
// 	// 		total_jumps = total_jumps + 1;
// 	// 	}
//     //     else{}
// 	// 	str_out = str_out + ".L";
// 	// 	str_out = str_out + std::to_string(total_jumps - 2) + ":\n";
// 	// 	str_out = "   movl	$0, ";

// 	// 	if(our_type == 3 || our_type == 1){
// 	// 		str_out = str_out + "%eax\n";
// 	// 	}
// 	// 	else if(our_type == 4 || our_type == 2){
// 	// 		str_out = str_out + "%ecx\n";
// 	// 	}
//     //     else{}
// 	// 	if(id == "OR_OP"){
// 	// 		str_out = str_out + ".L";
// 	// 		str_out = str_out + std::to_string(total_jumps - 2) + ":\n";
// 	// 	}
// 	// 	else{
// 	// 		str_out = str_out + ".L";
// 	// 		str_out = str_out + std::to_string(total_jumps) + ":\n";
// 	// 		total_jumps = total_jumps + 2;
// 	// 	}
//     //     cout << str_out;

// 	// }

	

// 	if((id == "OR_OP") && (our_type == 1 || our_type == 2 || our_type == 3 || our_type == 4)){
// 		int here_type;
// 		here_type = our_type;
// 		our_type = 3;
//         left->print(0);
// 		our_type = here_type;
//         comparegencode("jne", total_jumps);
//         total_jumps++;
// 		here_type = our_type;
// 		our_type = 3;
//         right->print(0);
// 		our_type = here_type;
// 	    comparegencode("je", total_jumps);
//         total_jumps++;
//         jump_statement(total_jumps-2);
// 	    printmovlorand(our_type, 1);
// 	    cout << "   jmp	.L" << total_jumps << "\n";
//         total_jumps++;
//         jump_statement(total_jumps-2);
//         printmovlorand(our_type, 0);
//         jump_statement(total_jumps-1);
//     }

    
	






	




	


// 	string str = "\"" + id + "\"";
// 	char *str1 = const_cast<char *>(str.c_str());
// 	// printAst("op_binary", "saa", "op", str1, "left", left, "right", right);
// }

// ///////////////////////////////////

// op_unary_astnode::op_unary_astnode(string val) : exp_astnode()
// {
// 	id = val;
// 	astnode_type = OpUnaryNode;
// }

// void op_unary_astnode::print(int ntabs)

// {
// 	//#cout << "reached op_unary_astnode"<<endl;
// 	if(id == "TO_INT"){
// 		if(child){
// 			// cout << child->int_val << endl;
// 			// cout << child->idname() << endl;
	
// 		}
// 	}
// 	if(id == "TO_FLOAT"){
// 		if(child){
// 			// cout << child->int_val << endl;
// 			// cout << child->idname() << endl;
	
// 		}
// 	}
// 	if((id == "UMINUS") && (our_type == 3 || our_type == 4 || our_type == 5)){
// 		int here_type;
// 		here_type = our_type;
// 		our_type = here_type;		
//         child->print(0);
// 		our_type = here_type;
//         if(our_type == 3){ 
// 			cout << "   negl %eax\n";
// 		}
//         else if(our_type == 4) {
// 			cout << "   negl %ecx\n";
// 		}
// 		else if(our_type == 5){
// 			cout << "   negl %edx\n";
// 		}
//     }

//     if((id == "NOT") && (our_type == 3 || our_type == 4 || our_type == 5)){
//         int here_type;
// 		here_type = our_type;
// 		our_type = 3;		
//         child->print(0);
// 		our_type = here_type;
//         cout << "   cmpl $0, %eax\n";
// 	    cout << "   sete %al\n";
// 		//cout << "   movzbl %al, %eax\n";
		
//         if(our_type == 3){
// 			 cout << "   movzbl %al, %eax\n";
// 		}
//         else if(our_type == 4)
// 		{ cout << "   movzbl %al, %ecx\n";
// 		}
// 		else if(our_type == 5)
// 		{ cout << "   movzbl %al, %edx\n";
// 		}
		
//     }
	
// 	// string str = "\"" + id + "\"";
// 	// char *str1 = const_cast<char *>(str.c_str());
// 	// printAst("op_unary", "sa", "op", str1, "child", child);
// }

// op_unary_astnode::op_unary_astnode(string val, exp_astnode *l) : exp_astnode()
// {
// 	id = val;
// 	child = l;
// 	astnode_type = OpUnaryNode;
// }

// string op_unary_astnode::getoperator()
// {
// 	return id;
// }
// ///////////////////////////////////

// assignE_astnode::assignE_astnode(exp_astnode *l, exp_astnode *r) : exp_astnode()
// {
// 	left = l;
// 	right = r;
// 	astnode_type = AssignNode;
// }

// void assignE_astnode::print(int ntabs)

// {
// 	//#cout << "reached  assignE_astnode" << endl;
// 	our_type = 3;
// 	right->print(0);
// 	our_type = 1;
// 	left->print(0);
// 	//printAst("assignE", "aa", "left", left, "right", right);
// }

// ///////////////////////////////////

// funcall_astnode::funcall_astnode() : exp_astnode()
// {
// 	astnode_type = FunCallNode;
// }

// funcall_astnode::funcall_astnode(identifier_astnode *child)
// {
// 	funcname = child;
// 	astnode_type = FunCallNode;
// }

// void funcall_astnode::setname(string name)
// {
// 	funcname = new identifier_astnode(name);
// }

// void funcall_astnode::pushback(exp_astnode *subtree)
// {
// 	children.push_back(subtree);
// }

// void funcall_astnode::print(int ntabs)
// {
// 			//#cout << "reached funcall_astnode"<<endl;

// 	printAst("funcall", "al", "fname", funcname, "params", &children);
// }


// proccall_astnode::proccall_astnode (funcall_astnode *fc)
// {
// 	procname = fc->funcname;
// 	children = fc->children;
// }
// void proccall_astnode::print(int ntabs)
// {
// 	//#cout << "reached proccall_astnode"<<endl;

//     printAst("proccall", "al", "fname", procname, "params", &children);
// }
// /////////////////////////////////////

// intconst_astnode::intconst_astnode(int val) : exp_astnode()
// {
// 	value = val;
// 	astnode_type = IntConstNode;
// }

// void intconst_astnode::print(int ntabs)
// {
// 	//#cout << "reached  intconst_astnode" << endl;

	
// 	std::string str = "";
// 	str = str + "   movl $";
// 	str = str + std::to_string(value);
// 	if(our_type == 3){
		
// 		str = str + ", %eax\n";
// 		cout << str;
// 	}
// 	else if(our_type == 4){
		
// 		str = str + ", %ecx\n";
// 		cout << str;
// 	}
// 	else if(our_type == 5){
		
// 		str = str + ", %edx\n";
// 		cout << str;
// 	}
// 	else{

// 	}

// 	//printAst("", "i", "intconst", value);
// }
// /////////////////////////////////////
// floatconst_astnode::floatconst_astnode(float val) : exp_astnode()
// {
// 	value = val;
// 	astnode_type = FloatConstNode;
// }

// void floatconst_astnode::print(int ntabs)
// {
// 	//#cout << "reached floatconst_astnode"<<endl;
// 	std::string str = "";
// 	str = str + "   movl $";
// 	str = str + std::to_string(value);
// 	if(our_type == 3){
		
// 		str = str + ", %eax\n";
// 		cout << str;
// 	}
// 	else if(our_type == 3){
		
// 		str = str + ", %ecx\n";
// 		cout << str;
// 	}
// 	else if(our_type == 3){
		
// 		str = str + ", %edx\n";
// 		cout << str;
// 	}
// 	else{

// 	}
// 	//printAst("", "f", "floatconst", value);
// }
// ///////////////////////////////////
// stringconst_astnode::stringconst_astnode(string val) : exp_astnode()
// {
// 	value = val;
// 	astnode_type = StringConstNode;
// }

// void stringconst_astnode::print(int ntabs)
// {
// 	//#cout << "reached stringconst_astnode"<<endl;
// 	printAst("", "s", "stringconst", stringTocharstar(value));
// }

// // ref_astnode::ref_astnode() : exp_astnode()
// // {
// // 	lvalue = true;
// // }

// /////////////////////////////////

// identifier_astnode::identifier_astnode(string val) : ref_astnode()
// {
// 	id = val;
// 	astnode_type = IdentifierNode;
// }

// void identifier_astnode::print(int ntabs)
// {
// 	int our_offset;
// 	std::string str = "";
	
// 	for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
// 		if(a->first == id){
// 			our_offset = a->second.offset;

// 		}
//     		}
// 	//#cout << "reached  identifier_astnode" << endl;
// 	if(our_type == 1){
// 		str = str + "   movl %eax, ";
// 		str = str + std::to_string(our_offset);
// 		str = str + "(%ebp)\n";
// 		cout << str;
// 	}	
// 	else if(our_type == 4){
// 		str = str + "   movl ";
// 		str = str + std::to_string(our_offset);
// 		str = str + "(%ebp), %ecx\n";
// 		cout << str;
		
// 	}
// 	else if(our_type == 3){
// 		str = str + "   movl ";
// 		str = str + std::to_string(our_offset);
// 		str = str + "(%ebp), %eax\n";
// 		cout << str;
// 	}
// 	else if(our_type == 5){
// 		str = str + "   movl ";
// 		str = str + std::to_string(our_offset);
// 		str = str + "(%ebp), %edx\n";
// 		cout << str;
// 	}
// 	else if(our_type == 2){
// 		str = str + "   movl %ecx, ";
// 		str = str + std::to_string(our_offset);
// 		str = str + "(%ebp)\n";
// 		cout << str;
// 	}
// 	else if(our_type == -1){

// 	}
// 	else{

// 	}

   
   
// }

// ////////////////////////////////

// arrayref_astnode::arrayref_astnode(exp_astnode *l, exp_astnode *r) : ref_astnode() // again, changed from ref to exp
// {
// 	left = l;
// 	right = r;
// 	id = "ArrayRef";
// 	astnode_type = ArrayRefNode;
// }

// void arrayref_astnode::print(int ntabs)
// {
// 	//#cout << "reached arrayref_astnode"<<endl;
// 	printAst("arrayref", "aa", "array", left, "index", right);
// }

// ///////////////////////////////

// // pointer_astnode::pointer_astnode(ref_astnode *c) : ref_astnode()
// // {
// // 	child = c;
// // 	id = "Pointer";
// // 	astnode_type = PointerNode;
// // }

// // void pointer_astnode::print(int ntabs)
// // {
// // 	printAst("", "a", "pointer", child);
// // }

// ////////////////////////////////

// deref_astnode::deref_astnode(ref_astnode *c) : ref_astnode()
// {
// 	child = c;
// 	id = "Deref";
// 	astnode_type = DerefNode;
// }

// void deref_astnode::print(int ntabs)
// {
// 	//#cout << "reached deref_astnode"<<endl;
// 	printAst("", "a", "deref", child);
// }

// /////////////////////////////////

// member_astnode::member_astnode(exp_astnode *l, identifier_astnode *r) // change from ref to exp(1st arg)
// {
// 	left = l;
// 	right = r;
// 	astnode_type = MemberNode;
// }

// void member_astnode::print(int ntabs)
// {
// 	//#cout << "reached member_astnode"<<endl;
// 	printAst("member", "aa", "struct", left, "field", right);
// }

// /////////////////////////////////

// arrow_astnode::arrow_astnode(exp_astnode *l, identifier_astnode *r)
// {
// 	left = l;
// 	right = r;
// 	astnode_type = ArrowNode;
// }

// void arrow_astnode::print(int ntabs)
// {
// 	//#cout << "reached arrow_astnode"<<endl;
// 	printAst("arrow", "aa", "pointer", left, "field", right);
// }
// void printblanks(int blanks)
// {
// 	for (int i = 0; i < blanks; i++)
// 		cout << " ";
// }

// /////////////////////////////////

// void printAst(const char *astname, const char *fmt...) // fmt is a format string that tells about the type of the arguments.
// {
// 	typedef vector<abstract_astnode *> *pv;
// 	va_list args;
// 	va_start(args, fmt);
// 	if ((astname != NULL) && (astname[0] != '\0'))
// 	{
// 		// cout << "{ ";
// 		// cout << "\"" << astname << "\""
// 		// 	 << ": ";
// 	}
// 	//cout << "{" << endl;
// 	while (*fmt != '\0')
// 	{
// 		if (*fmt == 'a')
// 		{
// 			char *field = va_arg(args, char *);
// 			abstract_astnode *a = va_arg(args, abstract_astnode *);
// 			//cout << "\"" << field << "\": " << endl;

// 			a->print(0);
// 		}
// 		else if (*fmt == 's')
// 		{
// 			char *field = va_arg(args, char *);
// 			char *str = va_arg(args, char *);
// 			// cout << "\"" << field << "\": ";

// 			// cout << str << endl;
// 		}
// 		else if (*fmt == 'i')
// 		{
// 			char *field = va_arg(args, char *);
// 			int i = va_arg(args, int);
// 			// cout << "\"" << field << "\": ";

// 			// cout << i;
// 		}
// 		else if (*fmt == 'f')
// 		{
// 			char *field = va_arg(args, char *);
// 			double f = va_arg(args, double);
// 			// cout << "\"" << field << "\": ";
// 			// cout << f;
// 		}
// 		else if (*fmt == 'l')
// 		{
// 			char *field = va_arg(args, char *);
// 			pv f = va_arg(args, pv);
// 			// cout << "\"" << field << "\": ";
// 			// cout << "[" << endl;
// 			for (int i = 0; i < (int)f->size(); ++i)
// 			{
// 				(*f)[i]->print(0);
// 				// if (i < (int)f->size() - 1)
// 				// 	cout << "," << endl;
// 				// else
// 				// 	cout << endl;
// 			}
// 			//cout << endl;
// 			//cout << "]" << endl;
// 		}
// 		++fmt;
// 		//if (*fmt != '\0')
// 			//cout << "," << endl;
// 	}
// 	//cout << "}" << endl;
// 	if ((astname != NULL) && (astname[0] != '\0'))
// 		//cout << "}" << endl;
// 	va_end(args);
// }

// char *stringTocharstar(string str)
// {
// 	char *charstar = const_cast<char *>(str.c_str());
// 	return charstar;
// }


// printf_astnode::printf_astnode(string x){
// 	name = x;
// }

// printf_astnode::~printf_astnode(){

// }

// void printf_astnode::print(int ntabs){
// 	int size_counter = 4;

// 	for(int i = sequence.size()-1; i>=0; i--){
// 		//cout <<" hahahahhaaa "<< sequence[i]->idname()<< endl;
// 		//cout << "calling print\n";
// 		our_type = 3;
// 		sequence[i]->print(0);

// 		size_counter = size_counter +4;
// 		cout << "   pushl %eax\n";
// 	}  
// 	cout << "   pushl $.LC"<< total_print << "\n";
// 	cout << "   call printf\n";
// 	cout << "   addl $" << size_counter << ", %esp\n";
// }




























#include "ast.hh"
#include <cstdarg>
#include <bits/stdc++.h>
#include "symbtab.hh"
#include <unordered_map>
extern SymbTab gstfun;
//////////////////////////////

// statement_astnode::statement_astnode()
// {
// }

/////////////////////////////
// eax ecx edx esi edi ebx
//my order of 
map<std::string, SymbTabEntry> all_variables;
std::unordered_map<std::string, map<std::string, SymbTabEntry>> all_structs;
int total_jumps = 0;
int left_offset = 0;
int our_type;
int deref_count = 0;
int arrow_offset = 0;
void printmovlorand(int our_type , int zero_or_one){
    if(our_type == 1 || our_type == 3){
        cout << "   movl $" << std::to_string(zero_or_one) << ", %eax\n";
    }
	else if(our_type == 2 || our_type == 4){
        cout << "   movl $" << std::to_string(zero_or_one) << ", %ecx\n";
    }
}

void comparegencode(std::string jump_type, int jumps){
	std::string codeString;
	codeString += "   cmpl $0,";
	codeString = codeString + " %eax\n";
	codeString += "   " + jump_type +" .L" + std::to_string(jumps) + "\n";

	std::cout << codeString;
}

void onecompare(std::string jump_type, int jumps){
	std::string codeString;
	codeString += "   cmpl $1,";
	codeString = codeString + " %eax\n";
	codeString += "   " + jump_type +" .L" + std::to_string(jumps) + "\n";

	std::cout << codeString;
}


void jump_statement(int jumps){
	std::string codeString;
	codeString =  ".L" + std::to_string(jumps) + ":\n";
	std::cout << codeString;
}


empty_astnode::empty_astnode() : statement_astnode()
{
	astnode_type = EmptyNode;
}

void empty_astnode::print(int ntabs)
{
	//#cout << "\"empty\"" << endl;
}

//////////////////////////

seq_astnode::seq_astnode() : statement_astnode()
{
	
	astnode_type = SeqNode;
}

void seq_astnode::pushback(statement_astnode *child)
{
	children_nodes.push_back(child);
}

void seq_astnode::print(int ntabs)
{
	printblanks(ntabs);
	// int max_offset;
	// max_offset = 0;
	
	// 	for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
	// 		max_offset = max(max_offset , abs(a->second.offset));
	// 		//cout << a->first  <<"," << max_offset << endl;
    // 		}
	// cout << "   subl $"<<max_offset << ", %esp\n";
	printAst("", "l", "seq", &children_nodes);
}

///////////////////////////////////

assignS_astnode::assignS_astnode(exp_astnode *l, exp_astnode *r, string tc) : statement_astnode()
{
	typecast = tc;
	left = l;
	right = r;
	id = "Ass";
	astnode_type = AssNode;
}

void assignS_astnode::print(int ntabs)
{
	//#cout << " reached assignS_astnode" <<endl;
	our_type = 3;
	right->print(0);
	our_type = 1;
	left->print(0);
	//printAst("assignS", "aa", "left", left, "right", right);
}

///////////////////////////////////

return_astnode::return_astnode(exp_astnode *c) : statement_astnode()
{
	child = c;
	id = "Return";
	astnode_type = ReturnNode;
}
void return_astnode::print(int ntabs)
{

	int here_type;
	here_type = our_type;
	our_type = 3;
	child->print(0);
	
	our_type = here_type;
	

	if(our_type == 10){
		cout << "   movl %eax, %ebx\n";
		return;
	}
	else{
		cout << "   leave\n";
		cout << "   ret\n";
	}
	//#cout << "reached return_astnode"<<endl;
	//printAst("", "a", "return", child);
}

////////////////////////////////////

if_astnode::if_astnode(exp_astnode *l, statement_astnode *m, statement_astnode *r) : statement_astnode()
{
	left = l;
	middle = m;
	right = r;
	id = "If";
	astnode_type = IfNode;
}

void if_astnode::print(int ntabs)
{
	//#cout << "reached if_astnode "<< endl;
	int v = total_jumps;
	if(left){
		total_jumps = total_jumps +2;

		int here_type;
		here_type = our_type;
		our_type = 3;
        left->print(0);
		our_type = here_type;
		onecompare("jne", v);
		
		
	}
	else{}
	if(middle){
		int here_type_1;
		here_type_1 = our_type;
		our_type = 3;
        middle->print(0);
		our_type = here_type_1;
		cout << "   jmp	.L" << v+1 << "\n";

	}else{}
	if(right){
		jump_statement(v);
		int here_type_3;
		here_type_3 = our_type;
		our_type = 3;
        right->print(0);
		our_type = here_type_3;
		jump_statement(v+1);
	}
	else{
		jump_statement(v);
		int here_type_3;
		here_type_3 = our_type;
		our_type = 2;
        right->print(0);
		our_type = here_type_3;
		jump_statement(v+1);
	}
	
	// printAst("if", "aaa",
	// 		 "cond", left,
	// 		 "then", middle,
	// 		 "else", right);
}
////////////////////////////////////

while_astnode::while_astnode(exp_astnode *l, statement_astnode *r) : statement_astnode()
{
	left = l;
	right = r;
	id = "While";
	astnode_type = WhileNode;
}

void while_astnode::print(int ntabs)
{	
	int v = total_jumps;
	if(right){
		total_jumps = total_jumps + 2;
        cout << "   jmp	.L" << v << "\n";
		jump_statement(v+1);
		int here_type;
		here_type = our_type;
		our_type = 3;
		right->print(0);
		our_type = here_type;


	}
	if(left){
		jump_statement(v);
		int here_type_1;
		here_type_1 = our_type;
		our_type = 3;
		left->print(0);
		our_type = here_type_1;
		onecompare("je",v+1);
		


	}
	
	//#cout << "reached while_astnode"<<endl;
	// printAst("while", "aa",
	// 		 "cond", left,
	// 		 "stmt", right);
}
/////////////////////////////////

for_astnode::for_astnode(exp_astnode *l, exp_astnode *m1, exp_astnode *m2, statement_astnode *r) : statement_astnode()
{
	left = l;
	middle1 = m1;
	middle2 = m2;
	right = r;
	id = "For";
	astnode_type = ForNode;
}

void for_astnode::print(int ntabs)
{


	int v = total_jumps;
	if(left){
		
		total_jumps = total_jumps + 2;
		int here_type;
		here_type = our_type;
		our_type = 3;
        left->print(0);
		our_type = here_type;
        cout << "   jmp .L" << v << "\n";
		jump_statement(v+1);
	}
	else{

	}
	if(right){
		int here_type_3;
		here_type_3 = our_type;
		our_type = 3;
        right->print(0);
		our_type = here_type_3;
	}
	else{

	}
	if(middle2){
		int here_type_2;
		here_type_2 = our_type;
		our_type = 3;
        middle2->print(0);
		our_type = here_type_2;
		jump_statement(v);
	}
	else{

	}
	if(middle1){
		int here_type_1;
		here_type_1 = our_type;
		our_type = 3;
        middle1->print(0);
		our_type = here_type_1;
		onecompare("je", v+1);
		
	}
	else{

	}
	


	
    // cout << "\"body\": " << endl;
	//#cout << "reached for_astnode"<<endl;
// 	printAst("for", "aaaa",
// 			 "init", left,
// 			 "guard", middle1,
// 			 "step", middle2,
// 			 "body", right);
// 
}

//////////////////////////////////

// exp_astnode::exp_astnode() : abstract_astnode()
// {
// }

//////////////////////////////////
string exp_astnode::idname()
{
	return id;
};
op_binary_astnode::op_binary_astnode(string val, exp_astnode *l, exp_astnode *r) : exp_astnode()
{
	id = val;
	left = l;
	right = r;
	astnode_type = OpBinaryNode;
}

void op_binary_astnode::print(int ntabs)
{
	//#cout << "reached op_binary_astnode"<<endl;
	if((id == "PLUS_INT" || id == "MINUS_INT" || id == "MULT_INT" ) && (our_type == 3 || our_type == 4 || our_type == 5)){
		int here_type;
		std::string str_out;
		str_out = "";
		if (id == "PLUS_INT"){
		str_out = str_out + "   addl ";
		}
		else if( id == "MINUS_INT" ){
		str_out = str_out + "   subl ";
		}
		else if( id == "MULT_INT"){
		str_out = str_out + "   imull ";
		}
		here_type = our_type;
		left->print(0);
		our_type = our_type + 1;
		right->print(0);
		our_type = here_type;
		

		if(here_type==3){
			str_out = str_out + "%ecx, ";
			str_out = str_out + "%eax";
		}
		if(here_type == 5){
			str_out = str_out + "%esi, ";
			str_out = str_out + "%edx";
		}
		if(here_type == 4){
			str_out = str_out + "%edx, ";
			str_out = str_out + "%ecx";
		}
		
		cout << str_out << endl;

	}
	if((id == "DIV_INT") && (our_type == 3 || our_type == 4 || our_type == 5)){
		int here_type;
		std::string str_out;
		str_out = "";
		here_type = our_type;
		left->print(0);
		our_type = our_type + 1;
		right->print(0);
		our_type = here_type;
		if(here_type == 3){
			str_out+="   movl %eax, %edx\n";
            str_out+="   movl $1234, %eax\n";
            str_out+="   movl $0, %esi\n";
            str_out+="   movl %edx, %eax\n";
            str_out+="   cltd\n";
            str_out+="   idivl %ecx\n";
		}
		
		if(here_type == 4){
			
			str_out += "   movl %eax, %esi\n   movl %ecx, %eax\n   movl %edx, %edi\n";
            str_out = str_out + "   cltd\n";
            str_out = str_out + "   idivl %edi\n";
			str_out += "   movl %eax, %ecx\n   movl %esi, %eax\n";
            
		}

		if(here_type == 5){
			
			str_out += "   movl %eax, %edi\n   movl %edx, %eax\n";
			str_out = str_out + "   cltd\n";
			str_out = str_out + "   idivl %esi\n";
			str_out += "   movl %eax, %edx\n   movl %edi, %eax\n";
			
		}


		cout << str_out;
	}

	if((id == "AND_OP") && (our_type == 1 || our_type == 2 || our_type == 3 || our_type == 4)){
        int here_type;
		here_type = our_type;
		our_type = 3;
        left->print(0);
		our_type = here_type;
        comparegencode("je", total_jumps);
        here_type = our_type;
		our_type = 3;
        right->print(0);
		our_type = here_type;
	    comparegencode("je", total_jumps);
        total_jumps++;
	    printmovlorand(our_type, 1);
	    cout << "   jmp	.L" << total_jumps << "\n";
        jump_statement(total_jumps-1);
        printmovlorand(our_type, 0);
        jump_statement(total_jumps);
        total_jumps++;
        total_jumps++;
    }

	  if((id == "GT_OP_INT" || id == "LT_OP_INT" || id == "GE_OP_INT" || id == "LE_OP_INT" || id == "EQ_OP_INT" || id == "NE_OP_INT") && (our_type == 3 || our_type == 4 || our_type == 5)){
        int here_type;
		std::string str_out;
		str_out = "";
		here_type = our_type;
		left->print(0);
		our_type = our_type + 1;
		right->print(0);
		our_type = here_type;
		str_out = str_out + "   cmpl %ecx, ";
        if(here_type == 3){
			str_out = str_out + "%eax\n";
		}
        else if(here_type == 4){
			str_out = str_out + "%ecx\n";
		}
        else if(here_type == 5){
			str_out = str_out + "%edx\n";
		}
        else{

        }
		if(id == "GT_OP_INT"){
			str_out = str_out + "   setg %al\n";
		}
		else if(id == "LT_OP_INT"){
			str_out = str_out + "   setl %al\n";
		}
		else if(id == "GE_OP_INT"){
			str_out = str_out + "   setge %al\n";
		}
		else if(id == "LE_OP_INT"){
			str_out = str_out + "   setle %al\n";
		}
		else if(id == "EQ_OP_INT"){
			str_out = str_out + "   sete %al\n";
		}
		else if(id == "NE_OP_INT"){
			str_out = str_out + "   setne %al\n";
		}
        else{

        }
		str_out = str_out + "   movzbl %al, ";
        if(here_type == 3){
			str_out = str_out + "%eax\n";
		}
        else if(here_type == 4){
			str_out = str_out + "%ecx\n";
		}
        else if(here_type == 5){
			str_out = str_out + "%edx\n";
		}
        else{

        }
        cout << str_out;


        

    






    }

	

    // if(id == "OR_OP" || id == "AND_OP"){
	// 	int here_type;
	// 	std::string str_out;
	// 	str_out = "";
	// 	here_type = our_type;
	// 	our_type = 3;
	// 	left->print(0);
	// 	our_type = here_type;
	// 	cout << "   cmpl	$0, %eax\n";
	// 	if(id == "OR_OP"){
	// 		cout << "   jne ";
	// 	}
	// 	else{
	// 		cout << "   je  ";
	// 	}
      
	// 	cout << ".L" << std::to_string(total_jumps) << endl;
	// 	if(id == "OR_OP"){
	// 		total_jumps = total_jumps + 1;
	// 	}
    //     else{}
	// 	here_type = our_type;
	// 	our_type = 3;
	// 	right->print(0);
	// 	our_type = here_type;
		
	// 	cout << "   cmpl	$0, %eax\n";
	// 	cout << "   je  ";
	// 	cout << ".L" << std::to_string(total_jumps) << endl;
	// 	total_jumps = total_jumps + 1;

	// 	if(id == "OR_OP"){
	// 		cout << ".L" << std::to_string(total_jumps-2) << ":\n";

	// 	}
    //     else{}
	// 	str_out = "   movl	$1, ";

	// 	if(our_type == 3 || our_type == 1){
	// 		str_out = str_out + "%eax\n";
	// 	}
	// 	else if(our_type == 4 || our_type == 2){
	// 		str_out = str_out + "%ecx\n";
	// 	}
    //     else{}
	// 	str_out = str_out + "   jmp .L" + std::to_string(total_jumps) + "\n";
		
	// 	if(id == "OR_OP"){
			
	// 		total_jumps = total_jumps + 1;
	// 	}
    //     else{}
	// 	str_out = str_out + ".L";
	// 	str_out = str_out + std::to_string(total_jumps - 2) + ":\n";
	// 	str_out = "   movl	$0, ";

	// 	if(our_type == 3 || our_type == 1){
	// 		str_out = str_out + "%eax\n";
	// 	}
	// 	else if(our_type == 4 || our_type == 2){
	// 		str_out = str_out + "%ecx\n";
	// 	}
    //     else{}
	// 	if(id == "OR_OP"){
	// 		str_out = str_out + ".L";
	// 		str_out = str_out + std::to_string(total_jumps - 2) + ":\n";
	// 	}
	// 	else{
	// 		str_out = str_out + ".L";
	// 		str_out = str_out + std::to_string(total_jumps) + ":\n";
	// 		total_jumps = total_jumps + 2;
	// 	}
    //     cout << str_out;

	// }

	

	if((id == "OR_OP") && (our_type == 1 || our_type == 2 || our_type == 3 || our_type == 4)){
		int here_type;
		here_type = our_type;
		our_type = 3;
        left->print(0);
		our_type = here_type;
        comparegencode("jne", total_jumps);
        total_jumps++;
		here_type = our_type;
		our_type = 3;
        right->print(0);
		our_type = here_type;
	    comparegencode("je", total_jumps);
        total_jumps++;
        jump_statement(total_jumps-2);
	    printmovlorand(our_type, 1);
	    cout << "   jmp	.L" << total_jumps << "\n";
        total_jumps++;
        jump_statement(total_jumps-2);
        printmovlorand(our_type, 0);
        jump_statement(total_jumps-1);
    }

    
	






	




	


	string str = "\"" + id + "\"";
	char *str1 = const_cast<char *>(str.c_str());
	// printAst("op_binary", "saa", "op", str1, "left", left, "right", right);
}

///////////////////////////////////

op_unary_astnode::op_unary_astnode(string val) : exp_astnode()
{
	id = val;
	astnode_type = OpUnaryNode;
}

void op_unary_astnode::print(int ntabs)

{
	//#cout << "reached op_unary_astnode"<<endl;
	if(id == "TO_INT"){
		if(child){
			// cout << child->int_val << endl;
			// cout << child->idname() << endl;
	
		}
	}
	if(id == "TO_FLOAT"){
		if(child){
			// cout << child->int_val << endl;
			// cout << child->idname() << endl;
	
		}
	}
	if(id == "PP"){

		if(child){
			int here_type;
			here_type = our_type;
			our_type = here_type;		
			child->print(0);
			our_type = here_type;
			std::string str = "";
			std::string here_register = "";
			int our_offset = 0;
			for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
			if(a->first == child->idname()){ //idhar child_dynamic tha
				our_offset = a->second.offset;
			}
				}
			if(our_type == 1 | our_type == 2){
			if(our_type == 1){
				here_register = "%eax";
			}
			else if(our_type == 2){
				here_register = "%ecx";
			}
			str = str + "   movl " + here_register;
			str = str + ", " + "%edx\n";
			str = str + "   addl $1, " + here_register + "\n";
			int here_type_1;
			here_type_1 = our_type;
			if(our_type == 1){
				our_type = 1;
			}
			else if(our_type == 2){
				our_type = 2;
			}
			child->print(0);
			our_type = here_type_1;
			str = str + "   movl %edx, " + here_register + "\n";
			cout << str;
			}
			// if(our_type == 1){
			// 	cout << "   movl %eax, %edx\n";
			// 	cout << "   addl $1, %eax\n";
			// 	int here_type_1;
			// 	here_type_1 = our_type;
			// 	our_type = 1;
			// 	child->print(0);
			// 	our_type = here_type_1;
			// 	cout << "   movl %edx, %eax\n";
			// }
			// else if(our_type == 2){
			// 	cout << "   movl %ecx, %edx\n";
			// 	cout << "   addl $1, %ecx\n";
			// 	int here_type_1;
			// 	here_type_1 = our_type;
			// 	our_type = 2;
			// 	child->print(0);
			// 	our_type = here_type_1;
			// 	cout << "   movl %edx, %ecx\n";
			// }
			else if(our_type == 4){
			str = str + "   movl ";
			str = str + std::to_string(our_offset);
			str = str + "(%ebp), %ecx\n";
			//cout << str;
			
			}
			else if(our_type == 3){
			str = str + "   movl ";
			str = str + std::to_string(our_offset);
			str = str + "(%ebp), %eax\n";
			//cout << str;
			}
			else if(our_type == 5){
			str = str + "   movl ";
			str = str + std::to_string(our_offset);
			str = str + "(%ebp), %edx\n";
			//cout << str;
			}
			

		}
	// 	int here_type;
	// 	here_type = our_type;
	// 	our_type = here_type;		
    //     child->print(0);
	// 	our_type = here_type;
	// 	int our_offset;
	// 	std::string str = "";
	// 	identifier_astnode* child_dynamic_pp = dynamic_cast<identifier_astnode*>(child);
	// 	for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
	// 		if(a->first == child_dynamic_pp->idname()){ //idhar child_dynamic tha
	// 			our_offset = a->second.offset;
	// 		}
	// 			}
	// 	if(our_offset>=4)
	// 		our_offset = our_offset - 4;
	// if(our_type == 1){
	// 	str = str + "   movl %eax, ";
	// 	str = str + std::to_string(our_offset);
	// 	str = str + "(%ebp)\n";
	// 	//str = str + "addl $1, " + std::to_string(our_offset) + "(%ebp)\n";

	// 	cout << str;
	// }	
	// else if(our_type == 4){
	// 	str = str + "   movl ";
	// 	str = str + std::to_string(our_offset);
	// 	str = str + "(%ebp), %ecx\n";
	// 	cout << str;
		
	// }
	// else if(our_type == 3){
	// 	str = str + "   movl ";
	// 	str = str + std::to_string(our_offset);
	// 	str = str + "(%ebp), %eax\n";
	// 	cout << str;
	// }
	// else if(our_type == 5){
	// 	str = str + "   movl ";
	// 	str = str + std::to_string(our_offset);
	// 	str = str + "(%ebp), %edx\n";
	// 	cout << str;
	// }
	// else if(our_type == 2){
	// 	str = str + "   movl %ecx, ";
	// 	str = str + std::to_string(our_offset);
	// 	str = str + "(%ebp)\n";
	// 	cout << str;
	// }
	// else if(our_type == -1){

	// }
			
			
	}
	

	if(id == "UMINUS"){
		int here_type;
		here_type = our_type;
		our_type = here_type;		
        child->print(0);
		our_type = here_type;
        if(our_type == 3){ 
			cout << "   negl %eax\n";
		}
        else if(our_type == 4) {
			cout << "   negl %ecx\n";
		}
		else if(our_type == 5){
			cout << "   negl %edx\n";
		}
    }

    if(id == "NOT"){
        int here_type;
		here_type = our_type;
		our_type = 3;		
        child->print(0);
		our_type = here_type;
        cout << "   cmpl $0, %eax\n";
	    cout << "   sete %al\n";
		//cout << "   movzbl %al, %eax\n";
		
        if(our_type == 3){
			 cout << "   movzbl %al, %eax\n";
		}
        else if(our_type == 4)
		{ cout << "   movzbl %al, %ecx\n";
		}
		else if(our_type == 5)
		{ cout << "   movzbl %al, %edx\n";
		}
		
    }

	if(id == "ADDRESS"){
		int our_offset;
		for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
			if(a->first == child->idname()){ //idhar child_dynamic tha
				our_offset = a->second.offset;
			}
				}
		std::string str = "";
		str = str + "   leal ";
		str = str + std::to_string(our_offset);
		str = str + "(%ebp), %eax\n";
		cout << str;
	}
	
	if(id == "DEREF"){
		int here_deref_count;
		//cout << "deref count " << deref_count << endl;
		deref_count = deref_count + 1;
		int our_offset;
		for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
			//cout << "child name " << child->idname() << endl;

			if(child->idname() == "DEREF"){
				child->print(0);
				//deref_count = deref_count + 1;
				return;
			}
			//cout << "a first " << a->first << "    offset " << a->second.offset << endl;
			if(a->first == child->idname()){ //idhar child_dynamic tha
				our_offset = a->second.offset;
				here_deref_count = deref_count;
				deref_count = 0;
			}
				}
		//cout << "here deref count " << here_deref_count << endl;
		std::string str = "";
		if(our_offset>=4)
		our_offset = our_offset - 4;
		//#cout << "reached  identifier_astnode" << endl;
		if(our_type == 1){
			str = str + "   movl ";
			str = str + std::to_string(our_offset);
			str = str + "(%ebp), %edx\n";
			str = str + "   movl ";
			str = str + "%eax, ";
			str = str + "(%edx)\n";
			cout << str;
		}	
		else if(our_type == 4){
			str = str + "   movl ";
			str = str + std::to_string(our_offset);
			str = str + "(%ebp), %ecx\n";
			for(int i = 0 ; i < here_deref_count; i++){
			str = str + "   movl ";
			str = str + "(%ecx), ";
			str = str + "%ecx\n";
			}
			cout << str;
			
		}
		else if(our_type == 3){
			str = str + "   movl ";
			str = str + std::to_string(our_offset);
			str = str + "(%ebp), %eax\n";
			for(int i = 0 ; i < here_deref_count; i++){
			str = str + "   movl ";
			str = str + "(%eax), ";
			str = str + "%eax\n";
			}

			cout << str;
		}
		else if(our_type == 5){
			str = str + "   movl ";
			str = str + std::to_string(our_offset);
			str = str + "(%ebp), %edx\n";
			for(int i = 0 ; i < here_deref_count; i++){
			str = str + "   movl ";
			str = str + "(%edx), ";
			str = str + "%edx\n";
			}
			cout << str;
		}
		else if(our_type == 2){
			str = str + "   movl ";
			str = str + std::to_string(our_offset);
			str = str + "(%ebp), %edx\n";
			str = str + "   movl ";
			str = str + "%ecx, ";
			str = str + "(%edx)\n";
			cout << str;
		}
		else if(our_type == -1){

		}
		else{

		}

	}
	// string str = "\"" + id + "\"";
	// char *str1 = const_cast<char *>(str.c_str());
	// printAst("op_unary", "sa", "op", str1, "child", child);
}

op_unary_astnode::op_unary_astnode(string val, exp_astnode *l) : exp_astnode()
{
	id = val;
	child = l;
	astnode_type = OpUnaryNode;
}

string op_unary_astnode::getoperator()
{
	return id;
}
///////////////////////////////////

assignE_astnode::assignE_astnode(exp_astnode *l, exp_astnode *r) : exp_astnode()
{
	left = l;
	right = r;
	astnode_type = AssignNode;
}

void assignE_astnode::print(int ntabs)

{
	//#cout << "reached  assignE_astnode" << endl;
	our_type = 3;
	right->print(0);
	our_type = 1;
	left->print(0);
	//printAst("assignE", "aa", "left", left, "right", right);
}

///////////////////////////////////

funcall_astnode::funcall_astnode() : exp_astnode()
{
	astnode_type = FunCallNode;
}

funcall_astnode::funcall_astnode(identifier_astnode *child)
{
	funcname = child;
	astnode_type = FunCallNode;
}

void funcall_astnode::setname(string name)
{
	funcname = new identifier_astnode(name);
}

void funcall_astnode::pushback(exp_astnode *subtree)
{
	children.push_back(subtree);
}

void funcall_astnode::print(int ntabs)
{
			//#cout << "reached funcall_astnode"<<endl;
			if(our_type == 3){
		cout << "   movl %ebx, %eax\n";
	}
	if(our_type == 4){
		cout << "   movl %ebx, %ecx\n";
	}
	if(our_type == 5){
		cout << "   movl %ebx, %edx\n";
	}
	int size_counter = 0;
	
	for(int i = 0 ; i<=children.size()-1; i++){
		//cout <<" hahahahhaaa "<< sequence[i]->idname()<< endl;
		//cout << "calling print\n";
		int here_type;
		here_type = our_type;
		our_type = 3;
		children[i]->print(0);
		our_type = here_type;

		size_counter = size_counter +4;
		cout << "   pushl %eax\n";
	}  
	//cout << "   pushl $.LC"<< total_print << "\n";
	cout << "   call " << funcname->idname() << endl;
	cout << "   addl $" << size_counter << ", %esp\n";
	cout << "   movl %eax, %ebx\n";

	// if(our_type == 3){
	// 	cout << "   movl %ebx, %eax\n";
	// }
	// if(our_type == 4){
	// 	cout << "   movl %eax, %ecx\n";
	// }
	// if(our_type == 5){
	// 	cout << "   movl %eax, %edx\n";
	// }
	
	
	 //cout << our_type << endl;

	//printAst("funcall", "al", "fname", funcname, "params", &children);
}


proccall_astnode::proccall_astnode (funcall_astnode *fc)
{
	procname = fc->funcname;
	children = fc->children;
}
void proccall_astnode::print(int ntabs)
{
	//#cout << "reached proccall_astnode"<<endl;
	// int size_counter = 0;

	// for(int i = 0 ; i<=children.size()-1; i++){
	// 	//cout <<" hahahahhaaa "<< sequence[i]->idname()<< endl;
	// 	//cout << "calling print\n";
	// 	our_type = 3;
	// 	children[i]->print(0);
	// 	our_type = 3;

	// 	size_counter = size_counter +4;
	// 	cout << "   pushl %eax\n";
	// }  
	// //cout << "   pushl $.LC"<< total_print << "\n";
	// cout << "   call " << procname->idname() << endl;
	// cout << "   addl $" << size_counter << ", %esp\n";

    //printAst("proccall", "al", "fname", procname, "params", &children);

	if(our_type == 3){
		cout << "   movl %ebx, %eax\n";
	}
	if(our_type == 4){
		cout << "   movl %ebx, %ecx\n";
	}
	if(our_type == 5){
		cout << "   movl %ebx, %edx\n";
	}
	int size_counter = 0;
	
	for(int i = 0 ; i<=children.size()-1; i++){
		//cout <<" hahahahhaaa "<< sequence[i]->idname()<< endl;
		//cout << "calling print\n";
		
		int here_type;
		here_type = our_type;
		our_type = 3;
		children[i]->print(0);
		our_type = here_type;

		size_counter = size_counter +4;
		cout << "   pushl %eax\n";
	}  
	//cout << "   pushl $.LC"<< total_print << "\n";
	cout << "   call " << procname->idname() << endl;
	cout << "   addl $" << size_counter << ", %esp\n";
	cout << "   movl %eax, %ebx\n";
	// if(our_type == 3){
	// 	cout << "   movl %ebx, %eax\n";
	// }
	// if(our_type == 4){
	// 	cout << "   movl %eax, %ecx\n";
	// }
	// if(our_type == 5){
	// 	cout << "   movl %eax, %edx\n";
	// }
}
/////////////////////////////////////

intconst_astnode::intconst_astnode(int val) : exp_astnode()
{
	value = val;
	astnode_type = IntConstNode;
}

void intconst_astnode::print(int ntabs)
{
	//#cout << "reached  intconst_astnode" << endl;

	
	std::string str = "";
	str = str + "   movl $";
	str = str + std::to_string(value);
	if(our_type == 3){
		
		str = str + ", %eax\n";
		cout << str;
	}
	else if(our_type == 4){
		
		str = str + ", %ecx\n";
		cout << str;
	}
	else if(our_type == 5){
		
		str = str + ", %edx\n";
		cout << str;
	}
	else{

	}

	//printAst("", "i", "intconst", value);
}
/////////////////////////////////////
floatconst_astnode::floatconst_astnode(float val) : exp_astnode()
{
	value = val;
	astnode_type = FloatConstNode;
}

void floatconst_astnode::print(int ntabs)
{
	//#cout << "reached floatconst_astnode"<<endl;
	std::string str = "";
	str = str + "   movl $";
	str = str + std::to_string(value);
	if(our_type == 3){
		
		str = str + ", %eax\n";
		cout << str;
	}
	else if(our_type == 3){
		
		str = str + ", %ecx\n";
		cout << str;
	}
	else if(our_type == 3){
		
		str = str + ", %edx\n";
		cout << str;
	}
	else{

	}
	//printAst("", "f", "floatconst", value);
}
///////////////////////////////////
stringconst_astnode::stringconst_astnode(string val) : exp_astnode()
{
	value = val;
	astnode_type = StringConstNode;
}

void stringconst_astnode::print(int ntabs)
{
	//#cout << "reached stringconst_astnode"<<endl;
	printAst("", "s", "stringconst", stringTocharstar(value));
}

// ref_astnode::ref_astnode() : exp_astnode()
// {
// 	lvalue = true;
// }

/////////////////////////////////

identifier_astnode::identifier_astnode(string val) : ref_astnode()
{
	id = val;
	astnode_type = IdentifierNode;
}

void identifier_astnode::print(int ntabs)
{
	int our_offset;
	std::string str = "";
	
	for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
		if(a->first == id){
			our_offset = a->second.offset;

		}
    		}
	if(our_offset>=4)
	our_offset = our_offset - 4;
	//#cout << "reached  identifier_astnode" << endl;
	if(our_type == 1){
		str = str + "   movl %eax, ";
		str = str + std::to_string(our_offset);
		str = str + "(%ebp)\n";
		cout << str;
	}	
	else if(our_type == 4){
		str = str + "   movl ";
		str = str + std::to_string(our_offset);
		str = str + "(%ebp), %ecx\n";
		cout << str;
		
	}
	else if(our_type == 3){
		str = str + "   movl ";
		str = str + std::to_string(our_offset);
		str = str + "(%ebp), %eax\n";
		cout << str;
	}
	else if(our_type == 5){
		str = str + "   movl ";
		str = str + std::to_string(our_offset);
		str = str + "(%ebp), %edx\n";
		cout << str;
	}
	else if(our_type == 2){
		str = str + "   movl %ecx, ";
		str = str + std::to_string(our_offset);
		str = str + "(%ebp)\n";
		cout << str;
	}
	else if(our_type == -1){

	}
	else{

	}

   
   
}

////////////////////////////////

arrayref_astnode::arrayref_astnode(exp_astnode *l, exp_astnode *r) : ref_astnode() // again, changed from ref to exp
{
	left = l;
	right = r;
	id = "ArrayRef";
	astnode_type = ArrayRefNode;
}

void arrayref_astnode::print(int ntabs)
{


	// left->print(0);
	// if(our_type == 3){
	// 	cout << "   movl %eax, %ebx\n";
	// }
	// else if(our_type == 4){
	// 	cout << "   movl %ecx, %ebx\n";
	// }
	// else if(our_type == 5){
	// 	cout << "   movl %edx, %ebx\n";
	// }
	// right->print(0);
	// if(our_type == 3){
	// 	cout << "   movl %eax, %edi\n";
	// }
	// else if(our_type == 4){
	// 	cout << "   movl %ecx, %edi\n";
	// }
	// else if(our_type == 5){
	// 	cout << "   movl %edx, %edi\n";
	// }
	
    
	
    int here_type;
	here_type = our_type;
	our_type = 4;
	left->print(0);
	cout << "   movl %ecx, %ebx\n";
	our_type = here_type;
	here_type = our_type;
	our_type = 4;
	right->print(0);
	cout << "   movl %ecx, %edi\n";
	our_type = here_type;
	
	
	// cout << "   negl %edi\n";
	//cout << "   imull $"+to_string(4)+", %edi\n";
	

	int typeee = 0;
	// if(left->idname() == "ArrayRef"){
	// 	//cout << "left idname " << left->idname() << "  right idname " << right->idname() << endl;	

	// 	cout << "   imull $"+to_string(4)+", %edi\n";
	// 			cout << "   addl %edi, %ebx\n";
	// 			// if(typeee == 1){
	// 			// 	cout << "   addl $4, %eax\n";
	// 			// }
	// 			if(our_type == 3){
	// 				cout << "   movl (%eax), %eax\n";
	// 			}
	// 			else if(our_type == 4){
	// 				cout << "   movl (%eax), %ecx\n";
	// 			}
	// 			else if(our_type == 5){
	// 				cout << "   movl (%eax), %edx\n";
	// 			}
				
	// }
	// else{

	// }
	int here_offset = 0;

	/*
	
	if(left->idname() == "ArrayRef"){

		// int here_deref_count;
		//cout << "deref count " << deref_count << endl;
		// deref_count = deref_count + 1;
		// int our_offset;
		// for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
		// 	//cout << "child name " << child->idname() << endl;

		// 	if(child->idname() == "DEREF"){
		// 		child->print(0);
		// 		//deref_count = deref_count + 1;
		// 		return;
		// 	}
		// 	left->print(0)
		// 	//cout << "a first " << a->first << "    offset " << a->second.offset << endl;
		// 	if(a->first == child->idname()){ //idhar child_dynamic tha
		// 		our_offset = a->second.offset;
		// 		here_deref_count = deref_count;
		// 		deref_count = 0;
		// 	}
		// 		}
		//cout << "here deref count " << here_deref_count << endl;
		std::string str = "";
		here_type = our_type;
		our_type = 5;
		left->print(0);
		cout << "   movl %edx, %ebx\n";
		our_type = here_type;
		// if(our_offset>=4)
		// our_offset = our_offset - 4;
		//#cout << "reached  identifier_astnode" << endl;
		cout << "   movl (%ebx), %ebx\n";
		if(our_type == 1){
			// str = str + "   addl %ebx, %edi\n";
			// str = str + "   movl %eax, %ebx\n";
			// str = str + "   movl ";
			// str = str + "%ebx, %edx\n";
			str = str + "   movl ";
			str = str + "%eax, ";
			str = str + "(%ebx, %edi, 4)\n";
			cout << str;
		}	
		else if(our_type == 4){
			// str = str + "   movl ";
			// str = str + "%ebx, %ecx\n";
			str = str + "   movl ";
			str = str + "(%ebx, %edi, 4), ";
			str = str + "%ecx\n";
			
			cout << str;
			
		}
		else if(our_type == 3){
			// str = str + "   movl ";
			// str = str + "%ebx, %eax\n";
			str = str + "   movl ";
			str = str + "(%ebx, %edi, 4), ";
			str = str + "%eax\n";
			

			cout << str;
		}
		else if(our_type == 5){
			// str = str + "   movl ";
			// str = str + "%ebx, %edx\n";
			
			str = str + "   movl ";
			str = str + "(%ebx, %edi, 4), ";
			str = str + "%edx\n";
			
			cout << str;
		}
		else if(our_type == 2){
			// str = str + "   movl ";
			// str = str + "%ebx, %edx\n";
			str = str + "   movl ";
			str = str + "%ecx, ";
			str = str + "(%ebx, %edi, 4)\n";
			cout << str;
		}
		else if(our_type == -1){

		}
		else{

		}
		
		// left->print(0);
		// for (auto b = all_variables.begin(); b != all_variables.end(); ++b){
		
		// if(b->first == left->idname()){
		// 	int right_offset;
		// 	right_offset = b->second.offset;
		// 	cout << "   imull " + to_string(right_offset) + "%(ebp), " + "%ebx, %ebx\n";
		// 	if(our_type == 1){
		// 			cout << "   addl %ebx, %eax\n";
					
		// 		}
		// 		else if(our_type == 2){
		// 			cout << "   addl %ebx, %ecx\n";
		// 			cout << "   movl %eax, %ecx\n";	
					
					
		// 		}
				
				
				
		// 	    else if(our_type == 3){
		// 			cout << "   addl %ebx, %eax\n";
		// 		}
		// 		else if(our_type == 4){
		// 			cout << "   addl %ebx, %ecx\n";	
		// 			cout << "   movl %eax, %ecx\n";				
		// 		}
		// 		else if(our_type == 5){
		// 			cout << "   addl %ebx, %edx\n";	
		// 			cout << "   movl %eax, %edx\n";					
		// 		}
		// }
		// }


	}
	*/
	//cout << "left idname " << left->idname() << "  right idname " << right->idname() << endl;	
	for (auto a = all_variables.begin(); a != all_variables.end(); ++a){
		
		if(a->first == left->idname()){
			//cout << "a frst " << a->first << " a  offset " << a->second.offset << endl;
				// if(a->second.offset > 4){
				// 	typeee = 1;
				// }
				// else{}
				here_offset = here_offset +  a->second.offset;
				if(here_offset > 4){
					here_offset = here_offset + 4;   // ultaa happening
				}
				if(our_type == 1){
					cout << "   movl %eax, " + to_string(here_offset) + "(%ebp,%edi,4)\n";
					// cout << "   imull $"+to_string(4)+", %edi\n";
					// cout << "   addl %edi, %ebx\n";

					// cout << "   movl %eax, " + to_string(a->second.offset) + "(%ebp)\n";
					// cout << "   movl " + to_string(a->second.offset) + "(%ebp), %eax\n";
					
				}
				else if(our_type == 2){
					cout << "   movl %ecx, " + to_string(here_offset) + "(%ebp,%edi,4)\n";
					// cout << "   imull $"+to_string(4)+", %edi\n";
					// cout << "   addl %edi, %ebx\n";

					// cout << "   movl %eax, " + to_string(a->second.offset) + "(%ebp)\n";
					// cout << "   movl " + to_string(a->second.offset) + "(%ebp), %eax\n";
					
				}
				
				// cout << "case 1 " << a->second.offset << endl;
			

				// cout << "   imull $"+to_string(4)+", %edi\n";
				// cout << "   addl %edi, %ebx\n";
				// if(typeee == 1){
				// 	cout << "   addl $4, %eax\n";
				// }
				
			    else if(our_type == 3){
					cout << "   movl " + to_string(here_offset) + "(%ebp,%edi,4), %eax\n";
					// cout << "   imull $"+to_string(4)+", %edi\n";
					// cout << "   addl %edi, %ebx\n";
					// cout << "   movl " + to_string(a->second.offset) + "(%ebp), %eax\n";
					// cout << "   leal (%eax,%edi,4), %eax\n";
					
				}
				else if(our_type == 4){
					cout << "   movl " + to_string(here_offset) + "(%ebp,%edi,4), %ecx\n";
					// cout << "   imull $"+to_string(4)+", %edi\n";
					// cout << "   addl %edi, %ebx\n";
					// cout << "   movl %eax, %ecx\n";
					// cout << "   movl " + to_string(a->second.offset) + "(%ebp), %ecx\n";
					// cout << "   leal (%ecx,%edi,4), %ecx\n";
					
				}
				else if(our_type == 5){
					cout << "   movl " + to_string(here_offset) + "(%ebp,%edi,4), %edx\n";
					// cout << "   imull $"+to_string(4)+", %edi\n";
					// cout << "   addl %edi, %ebx\n";	
					// cout << "   movl %eax, %edx\n";
					// cout << "   movl " + to_string(a->second.offset) + "(%ebp), %edx\n";
					// cout << "   leal (%edx,%edi,4), %edx\n";
				}
				// else if(our_type == 1){
				// 	cout << "   movl " + to_string(a->second.offset) + "(%ebp), %eax\n";
				// }
				// else if(our_type == 2){
				// 	cout << "   movl " + to_string(a->second.offset) + "(%ebp), %ecx\n";
				// }
		}
		else{

		}
		
		//cout << "a first " << a->first << "  left idanem() " << left->idname() << "  right idname " << right->idname()  << endl;
	}
  

	
	// for (auto a = all_variables.begin(); a != all_variables.end(); ++a){
	// 	// cout << "   a offset " << a->second.offset << endl;
	// 	cout << "   imull $"+to_string(4)+", %edi\n";
	// 	cout << "   addl %edi, %ebx\n";
	// 	int typeeee = 0;
	// 	if(a->second.offset > 4){
	// 		typeeee = 1;
	// 	}
	// 		if(a->first == left->idname()){
				
	// 			if(our_type == 4){
	// 				cout << "   movl %eax, %ecx\n";
	// 			}
	// 			if(our_type == 5){
	// 				cout << "   movl %eax, %edx\n";
	// 			}
	// 		}
	// 		else{
	// 			if(typeeee == 1){
	// 				if(our_type == 3){
	// 				cout << "   movl 4(%eax), %eax\n";
	// 			}
	// 			if(our_type == 4){
	// 				cout << "   movl 4(%eax), %ecx\n";
	// 			}
	// 			if(our_type == 5){
	// 				cout << "   movl 4(%eax), %edx\n";
	// 			}
	// 			}
	// 			else{
	// 			if(our_type == 3){
	// 				cout << "   movl 0(%eax), %eax\n";
	// 			}
	// 			if(our_type == 4){
	// 				cout << "   movl 0(%eax), %ecx\n";
	// 			}
	// 			if(our_type == 5){
	// 				cout << "   movl 0(%eax), %edx\n";
	// 			}
	// 			}
	// 		}
			
	// }


	



	
	//#cout << "reached arrayref_astnode"<< endl;
    // Load the address of the array variable
    // int offset;
    // for (auto a = all_variables.begin(); a != all_variables.end(); ++a) {
    //     if (a->first == left->idname()) {
    //         offset = a->second.offset;
    //     }
    // }
	// if(offset > 4){
	// 	offset = offset - 4;
	// }
    // std::string str = "   movl ";
    // str += std::to_string(offset);
    // str += "(%ebp), %ebx\n";
    // cout << str;

    // // Compute the index value
	// int here_type;
	// here_type = our_type;
    // our_type = 3;
    // right->print(0);
    // our_type = here_type;

    // // Multiply the index by the size of the array element
    // cout << "   imull $4, %eax\n";

    // // Add the offset to the base address
    // cout << "   addl %eax, %ebx\n";

    // // Access the array element based on our_type
    // if (our_type == 3) {
    //     cout << "   movl (%ebx), %eax\n";
    // } else if (our_type == 4) {
    //     cout << "   movl (%ebx), %ecx\n";
    // } else if (our_type == 5) {
    //     cout << "   movl (%ebx), %edx\n";
    // } else if (our_type == 1) {
    //     cout << "   movl %eax, (%ebx)\n";
    // } else if (our_type == 2) {
    //     cout << "   movl %ecx, (%ebx)\n";
    // }


	//printAst("arrayref", "aa", "array", left, "index", right);
}

///////////////////////////////

// pointer_astnode::pointer_astnode(ref_astnode *c) : ref_astnode()
// {
// 	child = c;
// 	id = "Pointer";
// 	astnode_type = PointerNode;
// }

// void pointer_astnode::print(int ntabs)
// {
// 	printAst("", "a", "pointer", child);
// }

////////////////////////////////

deref_astnode::deref_astnode(ref_astnode *c) : ref_astnode()
{
	child = c;
	id = "Deref";
	astnode_type = DerefNode;
}

void deref_astnode::print(int ntabs)
{
	//#cout << "reached deref_astnode"<<endl;
	printAst("", "a", "deref", child);
}

/////////////////////////////////

member_astnode::member_astnode(exp_astnode *l, identifier_astnode *r) // change from ref to exp(1st arg)
{
	left = l;
	right = r;
	astnode_type = MemberNode;
}

void member_astnode::print(int ntabs)
{
		int here_type;
        here_type = our_type;
        our_type = 20;
        left->print(0);
        our_type = here_type;
        here_type = our_type;
        our_type = 20;
        right->print(0);
        our_type = here_type;
        int our_offset;
		for (auto a = all_variables.begin(); a != all_variables.end(); ++a){
			if(a->first == left->idname()){
				left_offset =  a->second.offset;
				for (auto c = all_structs.begin(); c != all_structs.end(); ++c){
					//cout << c->first << " a name " << a->first << endl;
						for (auto b = c->second.begin(); b != c->second.end(); ++b){
							//cout << b->first << " b second offset " << b->second.offset << endl;
							if(b->first == right->idname()){
								
								left_offset = left_offset + b->second.offset;
								if(b->second.type.structname.empty()){
									std::string str = "";
								//cout << "our offset " << left_offset << endl;

								if(left_offset>=4)
									left_offset = left_offset - 4;
								if(our_type == 1){
									str = str + "   movl %eax, ";
									str = str + std::to_string(left_offset);
									str = str + "(%ebp)\n";
									cout << str;
								}   
								else if(our_type == 4){
									str = str + "   movl ";
									str = str + std::to_string(left_offset);
									str = str + "(%ebp), %ecx\n";
									cout << str;
									
								}
								else if(our_type == 3){
									str = str + "   movl ";
									str = str + std::to_string(left_offset);
									str = str + "(%ebp), %eax\n";
									cout << str;
								}
								else if(our_type == 5){
									str = str + "   movl ";
									str = str + std::to_string(left_offset);
									str = str + "(%ebp), %edx\n";
									cout << str;
								}
								else if(our_type == 2){
									str = str + "   movl %ecx, ";
									str = str + std::to_string(left_offset);
									str = str + "(%ebp)\n";
									cout << str;
								}
								else if(our_type == -1){

								}
										
									left_offset = 0;
									return;
								}
							}
						}
					
				}
				
			}
		}
		std::string str = "";
		if(left_offset>=4)
			left_offset = left_offset - 4;
		if(our_type == 1){
			str = str + "   movl %eax, ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp)\n";
			cout << str;
		}   
		else if(our_type == 4){
			str = str + "   movl ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp), %ecx\n";
			cout << str;
			
		}
		else if(our_type == 3){
			str = str + "   movl ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp), %eax\n";
			cout << str;
		}
		else if(our_type == 5){
			str = str + "   movl ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp), %edx\n";
			cout << str;
		}
		else if(our_type == 2){
			str = str + "   movl %ecx, ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp)\n";
			cout << str;
		}
		else if(our_type == -1){

		}
	//#cout << "reached member_astnode"<<endl;
	//printAst("member", "aa", "struct", left, "field", right);
}

/////////////////////////////////

arrow_astnode::arrow_astnode(exp_astnode *l, identifier_astnode *r)
{
	left = l;
	right = r;
	astnode_type = ArrowNode;
}

void arrow_astnode::print(int ntabs)
{
   
    int here_type;
        here_type = our_type;
        our_type = 20;
        left->print(0);
        our_type = here_type;
        here_type = our_type;
        our_type = 20;
        right->print(0);
        our_type = here_type;
        int our_offset;
		int variable_offset = 0;
		for (auto a = all_variables.begin(); a != all_variables.end(); ++a){
			if(a->first == left->idname()){
				//arrow_offset =  a->second.offset;
				variable_offset = a->second.offset;
				for (auto c = all_structs.begin(); c != all_structs.end(); ++c){
					//cout << c->first << " a name " << a->first << endl;
						for (auto b = c->second.begin(); b != c->second.end(); ++b){
							//cout << b->first << " b second offset " << b->second.offset << endl;
							//cout << "b first " << b->first << " right idname " << right->idname() << " b offset " << b->second.offset << endl;
							if(b->first == right->idname()){
								
								arrow_offset = b->second.offset;
								if(b->second.type.structname.empty()){
									std::string str = "";
								//cout << "our offset " << left_offset << endl;

								if(variable_offset>=4)
									variable_offset = variable_offset - 4;
								if(our_type == 1){
									str = str + "   movl ";
									str = str + std::to_string(variable_offset);
									str = str + "(%ebp), %edx\n";
									str = str + "   movl %eax, ";
									str = str + std::to_string(arrow_offset);
									str = str + "(%edx)\n";
									cout << str;
								}   
								else if(our_type == 4){
									str = str + "   movl ";
									str = str + std::to_string(variable_offset);
									str = str + "(%ebp), %ecx\n";
									str = str + "   movl ";
									str = str + std::to_string(arrow_offset);
									str = str + "(%ecx), %ecx\n";

									cout << str;
									
								}
								else if(our_type == 3){
									str = str + "   movl ";
									str = str + std::to_string(variable_offset);
									str = str + "(%ebp), %eax\n";
									str = str + "   movl ";
									str = str + std::to_string(arrow_offset);
									str = str + "(%eax), %eax\n";

									cout << str;
								}
								else if(our_type == 5){
									str = str + "   movl ";
									str = str + std::to_string(variable_offset);
									str = str + "(%ebp), %edx\n";
									str = str + "   movl ";
									str = str + std::to_string(arrow_offset);
									str = str + "(%edx), %edx\n";
									cout << str;
								}
								else if(our_type == 2){
									str = str + "   movl ";
									str = str + std::to_string(variable_offset);
									str = str + "(%ebp), %edx\n";
									str = str + "   movl %ecx, ";
									str = str + std::to_string(arrow_offset);
									str = str + "(%edx)\n";
									cout << str;
								}
								else if(our_type == -1){

								}
										
									arrow_offset = 0;
									return;
								}
							}
						}
					
				}
				
			}
		}
		std::string str = "";
		if(left_offset>=4)
			left_offset = left_offset - 4;
		if(our_type == 1){
			str = str + "   movl %eax, ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp)\n";
			cout << str;
		}   
		else if(our_type == 4){
			str = str + "   movl ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp), %ecx\n";
			cout << str;
			
		}
		else if(our_type == 3){
			str = str + "   movl ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp), %eax\n";
			cout << str;
		}
		else if(our_type == 5){
			str = str + "   movl ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp), %edx\n";
			cout << str;
		}
		else if(our_type == 2){
			str = str + "   movl %ecx, ";
			str = str + std::to_string(left_offset);
			str = str + "(%ebp)\n";
			cout << str;
		}
		else if(our_type == -1){

		}

	//#cout << "reached arrow_astnode"<<endl;
	//cout << " ";
	//printAst("arrow", "aa", "pointer", left, "field", right);
}
void printblanks(int blanks)
{
	for (int i = 0; i < blanks; i++)
		cout << " ";
}

/////////////////////////////////

void printAst(const char *astname, const char *fmt...) // fmt is a format string that tells about the type of the arguments.
{
	typedef vector<abstract_astnode *> *pv;
	va_list args;
	va_start(args, fmt);
	if ((astname != NULL) && (astname[0] != '\0'))
	{
		// cout << "{ ";
		// cout << "\"" << astname << "\""
		// 	 << ": ";
	}
	//cout << "{" << endl;
	while (*fmt != '\0')
	{
		if (*fmt == 'a')
		{
			char *field = va_arg(args, char *);
			abstract_astnode *a = va_arg(args, abstract_astnode *);
			//cout << "\"" << field << "\": " << endl;

			a->print(0);
		}
		else if (*fmt == 's')
		{
			char *field = va_arg(args, char *);
			char *str = va_arg(args, char *);
			// cout << "\"" << field << "\": ";

			// cout << str << endl;
		}
		else if (*fmt == 'i')
		{
			char *field = va_arg(args, char *);
			int i = va_arg(args, int);
			// cout << "\"" << field << "\": ";

			// cout << i;
		}
		else if (*fmt == 'f')
		{
			char *field = va_arg(args, char *);
			double f = va_arg(args, double);
			// cout << "\"" << field << "\": ";
			// cout << f;
		}
		else if (*fmt == 'l')
		{
			char *field = va_arg(args, char *);
			pv f = va_arg(args, pv);
			// cout << "\"" << field << "\": ";
			// cout << "[" << endl;
			for (int i = 0; i < (int)f->size(); ++i)
			{
				(*f)[i]->print(0);
				// if (i < (int)f->size() - 1)
				// 	cout << "," << endl;
				// else
				// 	cout << endl;
			}
			//cout << endl;
			//cout << "]" << endl;
		}
		++fmt;
		//if (*fmt != '\0')
			//cout << "," << endl;
	}
	//cout << "}" << endl;
	if ((astname != NULL) && (astname[0] != '\0'))
		//cout << "}" << endl;
	va_end(args);
}

char *stringTocharstar(string str)
{
	char *charstar = const_cast<char *>(str.c_str());
	return charstar;
}


printf_astnode::printf_astnode(string x){
	name = x;
}

printf_astnode::~printf_astnode(){

}

void printf_astnode::print(int ntabs){
	//#cout << " reached printf_astnode \n";
	int size_counter = 4;

	for(int i = sequence.size()-1; i>=0; i--){
		//cout <<" hahahahhaaa "<< sequence[i]->idname()<< endl;
		//cout << "calling print\n";
		our_type = 3;
		sequence[i]->print(0);

		size_counter = size_counter +4;
		cout << "   pushl %eax\n";
	}  
	cout << "   pushl $.LC"<< total_print << "\n";
	cout << "   call printf\n";
	cout << "   addl $" << size_counter << ", %esp\n";
}




